<?php $__env->startComponent('mail::message'); ?>
# Tere tulemast taanielGram'i <?php echo e($username); ?>!

Parem kui Instagram, vaata järgi.

<br>
Taaniel
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Taaniel\taanielGram\resources\views/emails/welcome-email.blade.php ENDPATH**/ ?>