<?php $user = Auth::user();?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if($user->following->count() !== 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="font-weight-bold col-4 offset-3 pb-6">
                    <img src="<?php echo e($post->user->profile->profileImage()); ?>" class="rounded-circle w-100" style="max-width: 40px">
                    <a href="/profile/<?php echo e($post->user->username); ?>">
                        <span class="text-dark"><?php echo e($post->user->username); ?></span>
                    </a>
                    </span>
                <div class="row">
                    <div class="col-6 offset-3 pt-2">
                        <a href="/profile/<?php echo e($post->user->username); ?>">
                            <img src="/storage/<?php echo e($post->image); ?>" class="w-100">
                        </a>
                    </div>
                </div>
                <div class="row pt-2 pb-4">
                    <div class="col-6 offset-3">
                        <div>
                            <p>
                            <?php echo e($post->caption); ?>

                            </p><hr>
                        </div>
                    </div>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="child">
            <div class="h1">
                <div>Ei jälgi veel kedagi?</div>
                <div class="btn btn-outline-success font-weight-bold"><a href="/explore">Avasta, mida teised kasutajad postitavad!</a></div>
            </div>
        </div>
    <?php endif; ?>
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                <?php echo e($posts->links()); ?>

            </div>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Taaniel\taanielGram\resources\views/posts/index.blade.php ENDPATH**/ ?>